"""
sgi — Structural Geospatial Identification
==========================================

SGI answers: WHERE IS WHAT?

  GPS  → WHERE is the object?
  SGI  → WHAT  is the object?
  Together: passive identification, no camera, no radar.

Quick Start
-----------
>>> import sgi
>>> clf = sgi.train()
>>> clf.predict(sensor_window)
'truck'
>>> sgi.predict_proba(sensor_window)
{'human': 0.01, 'bicycle': 0.01, 'car': 0.03, 'truck': 0.94, 'drone': 0.01}

Author: Yahya Akbay | 2025
"""

__version__ = '1.0.0'
__author__  = 'Yahya Akbay'

from sgi.classifier import SGILightClassifier
from sgi._internal.features import SGIFeatureExtractor, FEATURE_NAMES
from sgi._internal.generator import generate_window, generate_dataset, DEFAULT_CLASSES
from sgi._internal.physics import (
    k_amplitude, k_to_delta_g, collective_k, gap_to_detector,
    DETECTOR_SENSITIVITIES, OBJECT_PARAMETERS, EPSILON,
)


def train(n_per_class=300, classes=None, verbose=True):
    """Train and return a new SGI-Light classifier."""
    clf = SGILightClassifier(classes=classes)
    clf.train(n_per_class=n_per_class, verbose=verbose)
    return clf


def load(path=None):
    """Load a saved SGI-Light model from disk."""
    return SGILightClassifier.load(path)


def predict(data, clf=None):
    """Classify one sensor window. Returns class label string."""
    if clf is None:
        clf = train(verbose=False)
    return clf.predict(data)


def predict_proba(data, clf=None):
    """Class probabilities for one sensor window. Returns dict."""
    if clf is None:
        clf = train(verbose=False)
    return clf.predict_proba(data)


def info():
    """Print package info and physical constants."""
    print(f"sgi v{__version__} — Structural Geospatial Identification")
    print(f"Author: {__author__}")
    print(f"Classes: {DEFAULT_CLASSES}")
    print(f"Features: {len(FEATURE_NAMES)}")
    print(f"SGI-Full: ε = {EPSILON:.4e}, K(human) ≈ {k_amplitude(80,1.4):.2e} m⁻¹")
    print(f"Gap to LIGO: ~35.8 orders of magnitude")


__all__ = [
    'SGILightClassifier', 'SGIFeatureExtractor',
    'train', 'load', 'predict', 'predict_proba', 'info',
    'generate_window', 'generate_dataset', 'DEFAULT_CLASSES',
    'FEATURE_NAMES', 'k_amplitude', 'k_to_delta_g',
    'collective_k', 'gap_to_detector',
    'DETECTOR_SENSITIVITIES', 'OBJECT_PARAMETERS', 'EPSILON',
    '__version__', '__author__',
]
